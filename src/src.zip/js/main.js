require('../css/less.less')
//require('../pages/index/index.less')
//import { commonLab } from './commonLab.js'